var protocol_v_m_e_search_view_interface_p =
[
    [ "showSearchViewWithTitle:callback:", "protocol_v_m_e_search_view_interface-p.html#ad4488532d09545173cefc5bfdd8a5e30", null ]
];