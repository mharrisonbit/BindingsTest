var searchData=
[
  ['getting_20started',['Getting started',['../index.html',1,'']]]
];
