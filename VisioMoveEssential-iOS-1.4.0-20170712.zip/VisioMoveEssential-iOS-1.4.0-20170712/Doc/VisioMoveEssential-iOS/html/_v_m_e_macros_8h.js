var _v_m_e_macros_8h =
[
    [ "VME_DEPRECATED", "_v_m_e_macros_8h.html#a17e8b8c1b39baf1cbb5e66a683b35823", null ],
    [ "VME_DEPRECATED_MSG", "_v_m_e_macros_8h.html#a2c91e79fdc3241e72230aa9c273d4bec", null ]
];