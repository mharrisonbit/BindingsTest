var searchData=
[
  ['faq_2etxt',['FAQ.txt',['../_f_a_q_8txt.html',1,'']]]
];
