var searchData=
[
  ['vme_5fdeprecated',['VME_DEPRECATED',['../_v_m_e_macros_8h.html#a17e8b8c1b39baf1cbb5e66a683b35823',1,'VMEMacros.h']]],
  ['vme_5fdeprecated_5fmsg',['VME_DEPRECATED_MSG',['../_v_m_e_macros_8h.html#a2c91e79fdc3241e72230aa9c273d4bec',1,'VMEMacros.h']]],
  ['vme_5fmin_5fdata_5fsdk_5fversion_5fstring',['VME_MIN_DATA_SDK_VERSION_STRING',['../_visio_move_essential_8h.html#a12f541e83991c949b63c93c627eb006f',1,'VisioMoveEssential.h']]],
  ['vme_5fversion_5fstring',['VME_VERSION_STRING',['../_visio_move_essential_8h.html#ac335cc0a56093d51a93a5c7b5b8a8902',1,'VisioMoveEssential.h']]]
];
