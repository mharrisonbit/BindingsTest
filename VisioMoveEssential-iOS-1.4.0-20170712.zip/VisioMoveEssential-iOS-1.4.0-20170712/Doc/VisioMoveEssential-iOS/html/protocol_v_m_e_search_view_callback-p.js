var protocol_v_m_e_search_view_callback_p =
[
    [ "searchView:didSelectPlaceID:", "protocol_v_m_e_search_view_callback-p.html#a5139a8762608641278536fab576dcae3", null ],
    [ "searchViewDidCancel:", "protocol_v_m_e_search_view_callback-p.html#ab1fd00e45ed279b357c5fdb6d3f8af86", null ]
];