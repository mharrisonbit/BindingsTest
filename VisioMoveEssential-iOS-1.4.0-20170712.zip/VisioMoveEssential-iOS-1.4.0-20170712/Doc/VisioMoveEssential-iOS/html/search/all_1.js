var searchData=
[
  ['bearing',['bearing',['../interface_v_m_e_location.html#a6bcedaef1b1f40a0509723efb3776149',1,'VMELocation']]],
  ['buildingid',['buildingID',['../interface_v_m_e_position.html#ad36ee3897d34abcf702e40c4383349c6',1,'VMEPosition']]]
];
