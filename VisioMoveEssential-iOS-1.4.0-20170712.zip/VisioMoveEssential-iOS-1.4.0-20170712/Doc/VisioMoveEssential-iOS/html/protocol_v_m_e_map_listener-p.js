var protocol_v_m_e_map_listener_p =
[
    [ "map:didSelectPlace:withPosition:", "protocol_v_m_e_map_listener-p.html#aca9eb41fa1adf7f27627302491fa2d2c", null ],
    [ "mapDidLoad:", "protocol_v_m_e_map_listener-p.html#a40676b128ebbb133f0a4b5047012dfbb", null ],
    [ "mapReadyForPlaceUpdate:", "protocol_v_m_e_map_listener-p.html#a311372f6e6dc154a99cb48e625276499", null ]
];