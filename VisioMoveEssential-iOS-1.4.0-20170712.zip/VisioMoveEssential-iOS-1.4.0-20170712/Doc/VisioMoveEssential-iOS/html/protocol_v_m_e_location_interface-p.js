var protocol_v_m_e_location_interface_p =
[
    [ "createLocationFromLocation:", "protocol_v_m_e_location_interface-p.html#a4d8c9f46e2c5733390e11bed7cc4ce92", null ],
    [ "createPositionFromLocation:", "protocol_v_m_e_location_interface-p.html#a2eef584253bc6ad0ddc223d44cf43a55", null ],
    [ "updateLocation:", "protocol_v_m_e_location_interface-p.html#ab4a7b86930eec5fb6d793ab2dcc9fed5", null ]
];