var searchData=
[
  ['getdestinations',['getDestinations',['../interface_v_m_e_route_request.html#a7d050d533b428bdd51ee041c867dcfeb',1,'VMERouteRequest']]],
  ['getmindatasdkversion',['getMinDataSDKVersion',['../interface_v_m_e_map_view.html#a888864b303e16918af760deb3d271685',1,'VMEMapView']]],
  ['getorigin',['getOrigin',['../interface_v_m_e_route_request.html#a106d1bd2cbcdc8b1654e5db7a961322b',1,'VMERouteRequest']]],
  ['getversion',['getVersion',['../interface_v_m_e_map_view.html#aac4254d8f03ca0dd56b662af3f853b00',1,'VMEMapView']]],
  ['getting_20started',['Getting started',['../index.html',1,'']]]
];
